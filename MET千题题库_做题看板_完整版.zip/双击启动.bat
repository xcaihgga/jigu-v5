@echo off
chcp 65001 >nul
title MET肌肉能量技术千题题库 - 做题看板版
color 0B

cls
echo ==========================================
echo    MET肌肉能量技术千题题库
echo    做题看板版
echo ==========================================
echo.
echo 正在启动题库...
echo.

REM 获取当前目录
set "CURRENT_DIR=%~dp0"
set "HTML_FILE=%CURRENT_DIR%MET题库_做题看板_完整版.html"

REM 检查HTML文件是否存在
if not exist "%HTML_FILE%" (
    echo 错误：找不到题库文件！
    echo 请确保 MET题库_做题看板_完整版.html 与本文件在同一目录
    pause
    exit /b 1
)

REM 尝试使用默认浏览器打开
echo 正在打开浏览器...
start "" "%HTML_FILE%"

if %errorlevel% neq 0 (
    echo.
    echo 自动打开失败，请手动打开以下文件：
    echo %HTML_FILE%
    pause
) else (
    echo.
    echo 题库已启动！
    echo 如果浏览器没有自动打开，请手动打开：
    echo %HTML_FILE%
    echo.
    timeout /t 3 >nul
)

exit