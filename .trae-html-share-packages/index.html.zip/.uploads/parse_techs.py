# 解析 康复治疗技术速查表.docx → 结构化 JSON
# 方案：表格 5 列数据（名称/适应症/操作/禁忌/循证） + 段落序号行（序号/标题/⚠️）
import zipfile, re, json

P = '/workspace/.uploads/f22b4a65-0cf7-4bb5-92fc-059e50e46351_康复治疗技术速查表 Word版（精修版）.docx'
z = zipfile.ZipFile(P)
xml = z.read('word/document.xml').decode('utf8')

def cell_text(tc):
    out = []
    for pa in re.findall(r'<w:p[ >].*?</w:p>', tc, re.S):
        t = ''.join(re.findall(r'<w:t[^>]*>([^<]*)</w:t>', pa))
        t = t.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
        if t.strip():
            out.append(t.strip())
    return '\n'.join(out)

# 1) 段落序号行：数字. 标题（可能带⚠️）
paras_txt = []
for pa in re.findall(r'<w:p[ >].*?</w:p>', xml, re.S):
    t = ''.join(re.findall(r'<w:t[^>]*>([^<]*)</w:t>', pa)).strip()
    if t:
        paras_txt.append(t)
chapters = [l for l in paras_txt if re.match(r'^第[一二三四五六七八九十]+章', l)]

titles = []
for l in paras_txt:
    m = re.match(r'^(\d+)\.\s+(.*)$', l)
    if m:
        num = int(m.group(1))
        raw = m.group(2).strip()
        warn = '⚠️' in raw or '⚠' in raw
        titles.append({'num': num, 'title': raw.replace('⚠️', '').replace('⚠', '').strip(), 'warn': warn})
print('段落序号行:', len(titles))

# 2) 表格数据（按出现顺序，与标题顺序一致）
HEADER = ['技术名称', '适应症', '核心操作要点', '禁忌证', '临床适用场景与循证参考']
tables = re.findall(r'<w:tbl>.*?</w:tbl>', xml, re.S)

table_rows = []
for tbl in tables:
    rows = re.findall(r'<w:tr[ >].*?</w:tr>', tbl, re.S)
    if len(rows) < 2:
        continue
    header_cells = [cell_text(c) for c in re.findall(r'<w:tc[ >].*?</w:tc>', rows[0], re.S)]
    data_cells = [cell_text(c) for c in re.findall(r'<w:tc[ >].*?</w:tc>', rows[1], re.S)]
    def col(name):
        for i, h in enumerate(header_cells):
            if h.strip() == name:
                return data_cells[i] if i < len(data_cells) else ''
        return ''
    table_rows.append({
        'name': col('技术名称'),
        'indications': col('适应症'),
        'procedure': col('核心操作要点'),
        'contraindications': col('禁忌证'),
        'evidence': col('临床适用场景与循证参考'),
    })
print('表格数据行:', len(table_rows))

# 3) 合并
if len(titles) != len(table_rows):
    print('⚠️ 标题与表格行数不一致:', len(titles), 'vs', len(table_rows))
    n = min(len(titles), len(table_rows))
else:
    n = len(titles)

techs = []
for i in range(n):
    t = titles[i]
    r = table_rows[i]
    techs.append({
        'num': t['num'],
        'title': t['title'],
        'warn': t['warn'],
        'name': r['name'],
        'indications': r['indications'],
        'procedure': r['procedure'],
        'contraindications': r['contraindications'],
        'evidence': r['evidence'],
        'chapter': chapters[0] if t['num'] <= 25 else chapters[1]
    })

empty = [t for t in techs if not (t['indications'] and t['procedure'] and t['contraindications'] and t['evidence'] and t['name'])]
print('提取技术数:', len(techs), '| 字段缺失:', len(empty))
for t in empty:
    miss = [k for k in ['name','indications','procedure','contraindications','evidence'] if not t[k]]
    print('  ✗ #%d %s 缺: %s' % (t['num'], t['title'][:20], miss))
print('带⚠️:', sum(1 for t in techs if t['warn']))

# 名称一致性抽查
mismatch = [t for t in techs if t['name'] and t['name'][:6] != t['title'][:6]]
print('名称/标题前6字不一致:', len(mismatch))
for t in mismatch[:5]:
    print('  ? #%d 标题:%s / 表格:%s' % (t['num'], t['title'][:20], t['name'][:20]))

with open('/workspace/.uploads/techs-extracted.json', 'w', encoding='utf8') as f:
    json.dump(techs, f, ensure_ascii=False, indent=1)
print('已写出 techs-extracted.json')

for t in techs[:2]:
    print('\n--- #%d %s warn=%s ---' % (t['num'], t['title'], t['warn']))
    for k in ['name','indications','procedure','contraindications','evidence']:
        print('%s: %s' % (k, t[k][:80]))